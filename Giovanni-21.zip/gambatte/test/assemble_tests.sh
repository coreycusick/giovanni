#!/bin/sh
python qdgbas.py hwtests/*.asm hwtests/*/*.asm hwtests/*/*/*.asm hwtests/*/*/*/*.asm
